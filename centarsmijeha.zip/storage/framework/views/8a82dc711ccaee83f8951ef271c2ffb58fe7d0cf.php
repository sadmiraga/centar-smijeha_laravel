<?php $__env->startSection('content'); ?>

<div class="well" id="usredini">
    <h1>
        Promjeni lozinku
    </h1>
</div>



<?php if(session('error')): ?>
<div id="errorMessages" class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div id="errorMessages" class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

    <!-- ERRORI -->
    <?php if(count($errors)>0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="errorMessages" class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<div class="well" id="usredini">
    <?php echo Form::open(['action'=>'profileController@changePasswordSubmit','method'=>'POST']); ?>



        <!-- TRENUTNI PASSWORD -->
        <?php echo e(Form::password('currentPassword', array('placeholder'=>'Unesite trenutnu lozinku', 'class'=>'form-control'))); ?>

        <br>

        <!-- NOVI PASSWORD -->
        <?php echo e(Form::password('newPassword', array('placeholder'=>'Unesite novu lozinku', 'class'=>'form-control'))); ?>

        <br>

        <!-- RETYPE NOVI PASSWORD -->
        <?php echo e(Form::password('newPasswordCheck', array('placeholder'=>'Ponovo unesite novu lozinku', 'class'=>'form-control'))); ?>


        <br>
        <!-- SUBMIT -->
        <?php echo e(Form::submit('Spremi',['class'=>'btn btn-primary'])); ?>


    <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>