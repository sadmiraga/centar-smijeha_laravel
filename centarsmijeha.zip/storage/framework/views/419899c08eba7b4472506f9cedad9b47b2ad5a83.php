<?php $__env->startSection('content'); ?>

<?php
    $users = App\User::all();
?>



    <table class="table">
            <thead class="thead-dark">
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Ime</th>
                <th scope="col">E-mail</th>
                <th scope="col">Uloga</th>
                <th scope="col"></th>
                <th scope="col"></th>
              </tr>
            </thead>

            <tbody>
            
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!--ID -->
                <th scope="row">
                    <?php echo e($user->id); ?>

                </th>

                <!-- IME -->
                <td>
                    <?php echo e($user->name); ?>    
                </td>

                <!-- EMAIL -->
                <td>
                    <?php echo e($user->email); ?>    
                </td>

                <!-- ROLE/ULOGA-->
                <td>
                    <?php if(($user->role)==1): ?>
                        Head Admin
                    <?php elseif(($user->role)==2): ?>
                        Admin
                    <?php elseif(($user->role)==3): ?>
                        Korisnik
                    <?php endif; ?>
                </td>

                <!-- IZBRIŠI KORISNIKA -->
                <td>
                    <a href="/deleteUser/<?php echo e($user->id); ?>">
                        <button class="btn btn-primary">
                            Izbriši
                        </button>
                    </a>
                </td>

                <!-- UREDU KORISNIKA -->
                <td>
                    <a href="/editUser/<?php echo e($user->id); ?>">
                        <button class="btn btn-primary">
                            Uredi
                        </button>
                    </a>
                </td>                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody>
          </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>