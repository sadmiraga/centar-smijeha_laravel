<?php $__env->startSection('content'); ?>

<a href="/mojprofil/adminpanel/dodajkategoriju">
    <button class="btn btn-primary">
        Dodaj Kategoriju
    </button>
</a>
<?php echo $__env->yieldContent('adminSection'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>