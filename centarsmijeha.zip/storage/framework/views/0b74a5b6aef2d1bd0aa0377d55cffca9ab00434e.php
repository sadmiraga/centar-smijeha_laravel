<?php $__env->startSection('content'); ?>
    


    <table class="table">
        <thead>
                <th scope="col">Ime autora</th>
                <th scope="col">Text vica</th>
                <th scope="col">Kategorija</th>
                <th scope="col"></th>
                <th scope="col"></th>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $jokes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $joke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- GET IME AUTORA PREKO user_id iz fore-->
                <?php
                    $Autori = App\User::where('id',$joke->user_id)->get();

                    foreach($Autori as $autor){
                        $imeAutora = $autor->name;
                    }
                ?>

                <tr>
                    <td id="tabelaImeAutora">
                        <?php echo e($imeAutora); ?>

                    </td>

                    <td id="tabelaJokeText">
                        <?php
                            echo nl2br($joke->jokeText);
                        ?>
                    </td>

                    <td id="tabelaImeKategorije">
                        <!--TAKE CATEGORY NAME -->
                        <?php
                            $categories = App\category::where('id',$joke->category_id)->get();

                            //provuci kroz foreach
                            foreach($categories as $category){
                                $imeKategorije = $category->categoryName;
                            }
                        ?>
                        <?php echo e($imeKategorije); ?>

                    </td>

                    <td id="odobri_odbij">
                        <button onclick='location.href="/approveJoke/<?php echo e($joke->id); ?>"' class="btn btn-success">
                            Odobri
                        </button>
                    </td>

                    <td>
                        <button onclick='location.href="/declineJoke/<?php echo e($joke->id); ?>"' class="btn btn-danger">
                            Odbij
                        </button>
                    </td>
                </tr>   


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>