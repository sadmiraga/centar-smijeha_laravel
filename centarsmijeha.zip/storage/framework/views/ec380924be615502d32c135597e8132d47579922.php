<?php $__env->startSection('content'); ?>

<?php
    $categories = App\category::all();
?>
    <div class="well" id="usredini">
        <h1> Kategorije </h1>
    </div>

    <?php if(count($categories)>0): ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            
            <a href="/kategorije/<?php echo e($category->id); ?>">
                <button class="btn btn-primary" id="dugmeKategorije">
                    <p>
                        <?php echo e($category->categoryName); ?>

                    </p>
                </button>
            </a>
            <br>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <p> Nema kategorija </p>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>