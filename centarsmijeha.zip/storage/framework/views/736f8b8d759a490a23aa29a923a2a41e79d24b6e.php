<?php $__env->startSection('content'); ?>

<?php
    $userID = $user->id;
    $userRole = $user->role;
?>


<div class="alert alert-info" id="urediKorisnika">
    <?php echo e($user->name); ?>



    <?php if(count($errors)>0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="errorMessages" class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php echo Form::open(['action'=>['usersController@uredi',$userID],'method'=>'POST']); ?>

    <div class="form-group" id="submitform">
        <select name="role" class="form-control">

            <!-- DEFAULT HEAD ADMIN -->
            <?php if($userRole == 1): ?>
                <option selected="selected" value="1">Head Admin</option>
            <?php else: ?>
                <option value="1">Head Admin</option>
            <?php endif; ?>

            <!-- DEFAULT ADMIN -->
            <?php if($userRole == 2): ?>
                <option selected="selected" value="2">Admin</option>
            <?php else: ?>
                <option value="2">Admin</option>
            <?php endif; ?>

            <!-- DEFAULT USER -->
            <?php if($userRole == 3): ?>
                <option selected="selected" value="3">Korisnik</option>
            <?php else: ?> 
                <option value="3">Korisnik</option>
            <?php endif; ?>

        </select>
    
    </div>

   

    <div class="text-center">
        <?php echo e(Form::submit('Spremi',['class'=>'btn btn-primary'])); ?>

    </div>
<?php echo Form::close(); ?>



</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>