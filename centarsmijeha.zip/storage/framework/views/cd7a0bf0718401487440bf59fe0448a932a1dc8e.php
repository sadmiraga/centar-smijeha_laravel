<?php $__env->startSection('content'); ?>

<div class="well" id=usredini>
    <h1> Admin Panel </h1>
</div>

<div class="well" id="usredini">
    <!-- DODAJ KATEGORIJU -->
    <a href="/mojprofil/adminpanel/dodajkategoriju">
        <button class="btn btn-primary" id="dugme">
            Dodaj Kategoriju
        </button>
    </a>
    <br>
    <br>

    <!-- ODOBRI VICEVE -->
    <a href="/approveJokes">
        <button class="btn btn-primary" id="dugme">
            Odobri Viceve
        </button>
    </a>
    <br>
    <br>


    <?php echo $__env->yieldContent('adminSection'); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>