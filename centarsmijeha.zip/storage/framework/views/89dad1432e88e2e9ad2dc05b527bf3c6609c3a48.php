<?php $__env->startSection('content'); ?>

    <!-- POKUPITI VRIJEDNOST IMENA ZA PLACEHOLDER -->
    <?php
        $staroIme = Auth::user()->name;
    ?>

    <!-- NASLOV STRANICE -->
    <div class="well" id="usredini">
        <h1> Promjeni korisničko ime </h1>
    </div>

    <!-- ERRORI -->
    <?php if(count($errors)>0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="errorMessages" class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
    <div class="well" id="usredini">
        <!-- FORMA -->
        <?php echo Form::open(['action'=>'profileController@changeUsernameSubmit', 'method'=>'POST']); ?>

        
        <!-- text emaila-->
        <?php echo e(Form::text("newUsername","$staroIme",['class'=>'form-control'])); ?>

        <br>
        <!-- submit button -->
        <div style="text-align:center;">
        <?php echo e(Form::submit('Spremi',['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>