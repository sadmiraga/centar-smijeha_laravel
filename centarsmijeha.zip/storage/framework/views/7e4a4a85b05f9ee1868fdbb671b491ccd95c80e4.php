<?php $__env->startSection('content'); ?>
    


<?php
    $categories = App\category::all();
    $jokes = App\jokes::where('id',$joke_id)->get();
    foreach($jokes as $joke){
        $jokeValue = $joke->jokeText;
        $jokeCategoryID = $joke->category_id;
    }
?>
    <?php echo e($jokeCategoryID); ?>


    <?php if(count($errors)>0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="errorMessages" class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


    <div class="well" id="usredini">
    <?php echo Form::open(['action'=>['jokesController@update',$joke_id],'method'=>'POST']); ?>

        <div class="form-group" id="submitform">
            <?php echo e(Form::textarea('jokeText',"$jokeValue", ['class' => 'form-control', 'rows'=>'10', 'cols'=>'2'] )); ?>

            <br>

            <!-- DROPDOWN -->
            <select class="form-control" name="category_id">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(($category->id)==$jokeCategoryID): ?>
                    <option selected="selected" value =<?php echo e($category->id); ?>> <?php echo e($category->categoryName); ?> </option>
                    <?php else: ?> 
                        <option value =<?php echo e($category->id); ?>> <?php echo e($category->categoryName); ?> </option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            

        </div>

        <?php echo e(Form::hidden('_method','PUT')); ?>


        <div class="text-center">
            <?php echo e(Form::submit('Spremi',['class'=>'btn btn-primary'])); ?>

        </div>
    <?php echo Form::close(); ?>

    </div>


















<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>