<?php $__env->startSection('content'); ?>

    <div class="well" id="usredini">
        <h1> Top Vicevi </h1>
    </div>

  


    <!-- DA LI UOPSTE POSTOJE VICEVI KOJI SU LAJKOVANI -->
    <?php if(count($jokes)>0): ?>
        <?php $__currentLoopData = $jokes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $joke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- VRIJEDNOST USERNAMEA od autora koji je objavio ovaj vic preko id od vica -->
            <?php
                $users = App\User::where('id',$joke->user_id)->get();
                foreach($users as $user){
                    $username = $user->name;
                }
            ?>

            <!-- GLAVNI DIV U KOM SE NALAZI VIC -->
            <div class="alert alert-info" id="vic">


                <!-- ispis TEXTa vica -->
                <p style="style=align:center;" id="textVica">
                    <?php echo e($joke->jokeText); ?>

                </p>

                <!-- ispis imena autora -->
                <span id="imeAutora">
                    <?php echo e($username); ?>

                </span>
                <br>

                <!-- provjera da li je user prijavljen -->
                <?php if($juzer = Auth::user()): ?>
                    
                    <!-- Provjera da li je user vec lajko ovaj vic -->
                    <?php
                        $likeCount = App\likes::where([
                            'user_id' => Auth::id(),
                            'joke_id' => $joke->id
                        ])->get();
                    ?>

                    <!-- LIKE -->
                    <?php if(count($likeCount)==0): ?>
                        <button onclick='location.href="/likeByTop/<?php echo e($joke->id); ?>"' class="btn btn-primary">
                            Like
                        </button>
                    <!-- UNLIKE -->
                    <?php else: ?>
                        <button onclick='location.href="/unlikeByTop/<?php echo e($joke->id); ?>"' class="btn btn-primary">
                            Unlike 
                        </button>
                    <?php endif; ?>


                <?php endif; ?>

                <!-- BROJ LAJKOVA POVLACENJE IZ BAZE -->
                <?php
                    $lajkovi = App\likes::where('joke_id',$joke->id)->get();
                    $brojLajkova = count($lajkovi);
                ?>

                <!-- Ispis broja lajkova -->
                <button class="btn btn-primary">
                    <?php echo e($brojLajkova); ?>

                </button> 


            </div>

        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="well" id="usredini">
            <h3>
                Trenutno nije dostupno
            </h3>
        </div>
    <?php endif; ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>