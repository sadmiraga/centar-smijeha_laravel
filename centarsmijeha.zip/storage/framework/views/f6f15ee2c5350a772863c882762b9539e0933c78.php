<?php $__env->startSection('content'); ?>


<?php if(count($errors)>0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="errorMessages" class="alert alert-danger">
        <?php echo e($error); ?>

    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<div class="alert alert-info" id="usredini">
        
    <?php echo Form::open(['url' => '/submitCategory']); ?>

    <div class="form-group" id="submitform">
        <?php echo e(Form::textarea('categoryName','', ['class' => 'form-control', 'placeholder'=>'Upisite ime kategorije', 'rows'=>'3', 'cols'=>'2'] )); ?>

    </div>



    <div class="text-center">
        <?php echo e(Form::submit('Dodaj',['class'=>'btn btn-primary'])); ?>

    </div>
    <?php echo Form::close(); ?>

</div>











<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>