<?php $__env->startSection('content'); ?>

    <!-- VRIJEDNOST E-maila  za placeholder -->
    <?php
        $stariEmail = Auth::user()->email;
    ?>

    <!-- NASLOV STRANICE -->
    <div class="well" id="usredini">
        <h1> Promjeni Email </h1>
    </div>
    
    <!-- ERRORI -->
    <?php if(count($errors)>0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="errorMessages" class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


    <div class="well" id="usredini">
    <!-- FORMA -->
        <?php echo Form::open(['action'=>'profileController@changeEmailSubmit','method'=>'POST']); ?>

            <?php echo e(Form::text('newEmail',"$stariEmail",['class'=>'form-control'])); ?>

            <br>
            <div style="text-align:center;">
                <?php echo e(Form::submit('spremi',['class'=>'btn btn-primary'])); ?>

            </div>
        <?php echo FOrm::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>