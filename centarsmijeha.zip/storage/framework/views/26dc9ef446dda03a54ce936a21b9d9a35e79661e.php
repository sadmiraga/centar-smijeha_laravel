<?php $__env->startSection('content'); ?>

<?php
    $categories = App\category::all();
    
?>

    <div class="well" id="usredini">
        <h1>Posaljite novi vic </h1>
    </div>



    <!-- ispis svih errora sa forme -->
    <?php if(count($errors)>0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="errorMessages" class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <!-- Poruka u uspiješno poslanoj formi -->
    <?php if(Session::has('successMessage')): ?>
        <div id="errorMessages" class="alert alert-success" style="text-align:center; word-wrap:break-word;">
            <?php echo e(Session::get('successMessage')); ?>

        </div>
    <?php endif; ?>
    
    <!-- FORMA -->
    <div class="alert alert-info" id="usredini">
        <?php echo Form::open(['url' => 'posaljitevic/submit']); ?>

            <div class="form-group" id="submitform">
                <?php echo e(Form::textarea('jokeText','', ['class' => 'form-control', 'placeholder'=>'Napišite vic', 'rows'=>'3', 'cols'=>'2'] )); ?>

                <br>
                <label> Izaberite Kategoriju vica </label>
                <select class="form-control" name="category_id">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value =<?php echo e($category->id); ?>> <?php echo e($category->categoryName); ?> </option>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <?php if(Auth::guest()): ?>
                <!-- reCAPTCHA -->
                <div id="recaptcha-box">
                        <?php echo NoCaptcha::renderJs(); ?>

                        <?php echo NoCaptcha::display(); ?>

                </div>
                <br> 
            <?php endif; ?>

            <!--submit -->
            <div class="text-center">
                <?php echo e(Form::submit('Pošalji',['class'=>'btn btn-primary'])); ?>

            </div>

            <?php echo Form::close(); ?>

    </div>


        
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>