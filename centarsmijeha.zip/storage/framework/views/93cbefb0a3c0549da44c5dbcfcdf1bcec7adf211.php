<?php $__env->startSection('content'); ?>

<?php
    $categories = App\category::all();
?>
    <div class="well" id="usredini">
        <h1> Kategorije </h1>
    </div>

    <!-- Najbolji vicevi kategorija -->
    <button onclick='location.href="/najboljiVicevi"' class="btn btn-primary" id="dugme">
        Top Vicevi 
    </button>

    <!-- ispis svih kategorija -->
    <?php if(count($categories)>0): ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button onclick='location.href="/kategorije/<?php echo e($category->id); ?>"' class="btn btn-primary" id="dugme">
                        <?php echo e($category->categoryName); ?>

                </button>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <p> Nema kategorija </p>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>