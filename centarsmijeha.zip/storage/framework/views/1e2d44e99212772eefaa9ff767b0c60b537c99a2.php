<?php $__env->startSection('content'); ?>

<?php
    $userID = Auth::id();

    //POKUPITI ID OD KATEGORIJE 
    foreach($vicevi as $joke){
        $idKategorije = $joke->category_id;
    }

    //POKUPIT KATEGORJU POMOCU predhodno dobijenog IDa
    $kategorije = App\category::where('id',$idKategorije)->get();

    //IME KATEGORIJE, provuc kroz foreach i uzet ime kategorije
    foreach($kategorije as $kategorija){
        $imeKategorije = $kategorija->categoryName;
    }
?>

<div class="well" id="usredini">
    <h1> <?php echo e($imeKategorije); ?> </h1>
</div>

   







<!-- provjeriti da li ima viceva u ovoj kategoriji -->
<?php if(count($vicevi)>0): ?>
    <?php $__currentLoopData = $vicevi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $joke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!-- select USERNAME od authora -->
        <?php
            $users = App\User::where('id',$joke->user_id)->get();
            //pokupis vrijednost USERNAME
            foreach($users as $user){
                $username = $user->name;
            }
        ?>

        <div class="alert alert-info" id="vic">

            <!-- ispis TEXTa vica -->
            <p style="style=align:center;" id="textVica">
                <?php echo e($joke->jokeText); ?>

            </p>
            
            <!-- ispis imena autora -->
            <span id="imeAutora">
                <?php echo e($username); ?>

            </span>
            <br>

            <!-- provjera da li je user prijaveljen-->
            <?php if($juzer = Auth::user()): ?>

                <!-- provjera da li je user lajko ovaj vic -->
                <?php
                    $likeCount = App\likes::where([
                        'user_id' => $userID,
                        'joke_id' => $joke->id
                    ])->get();
                ?>
    
                    <!-- LIKE -->
                    <?php if(count($likeCount)==0): ?>
                        <a href="/likeByCategory/<?php echo e($joke->id); ?>/<?php echo e($joke->category_id); ?>">
                            <button  class="btn btn-primary">
                                Like
                            </button>
                        </a>
                    <!--UNLIKE -->                    
                    <?php else: ?>
                        <a href="/unlikeByCategory/<?php echo e($joke->id); ?>/<?php echo e($joke->category_id); ?>">
                            <button  class="btn btn-primary">
                                Unlike
                            </button>
                        </a>
                    <?php endif; ?>       
            <?php endif; ?>
                        <!-- BROJ LAJKOVA POVLACENJE IZ BAZE -->
                        <?php
                            $lajkovi = App\likes::where('joke_id',$joke->id)->get();
                            $brojLajkova = count($lajkovi);
                        ?>

                        <!-- Ispis broja lajkova -->
                        <button id="brojLajkova" class="btn btn-primary">
                            <?php echo e($brojLajkova); ?>

                        </button> 


        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p> Nema viceva u ovoj kategoriji </p>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>