<?php $__env->startSection('content'); ?>

<?php 

     $jokes = App\jokes::where('approve','yes')->orderBy('id','desc')->get();
     $userID = Auth::id();
     $likes = App\likes::where('user_id',$userID)->get();
?>
    


    

    <?php if(count($jokes)>0): ?>

        <?php $__currentLoopData = $jokes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $joke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!--SELECT USERNAME OF AUTHOR-->
        <?php
            $users = App\User::where('id',$joke->user_id)->get();

            //pokupis vrijednost USERNAMEA
            foreach($users as $user){
                $username = $user->name;
            }
        ?>



            
            <!-- TEXT VICA -->
            <div class="alert alert-info" id="vic">
                <!-- text vica -->
                <p style="text-align:center;" id="textVica">
                    <?php
                        echo nl2br($joke->jokeText);
                    ?>  
                </p>
                <!--ime Autora -->
                <span id="imeAutora"> 
                    <?php echo e($username); ?>

                </span>
                <br>
                


                <!-- provjeriti da li je user prijavljen i shodno tome ispisati like i unlike button -->
                <?php if($juzer = Auth::user()): ?>
                    <?php
                        $likeCount = App\likes::where([
                        'user_id' => $userID,
                        'joke_id' => $joke->id
                        ])->get();
                    ?>

                     
                        <!-- LIKE -->
                        <?php if(count($likeCount)==0): ?>
                            <a href="/like/<?php echo e($joke->id); ?>">
                                <button  class="btn btn-primary">
                                    Like
                                </button>
                            </a>
                        <!--UNLIKE -->
                        
                        <?php else: ?>
                            <a href="/unlike/<?php echo e($joke->id); ?>">
                                <button  class="btn btn-primary">
                                    Unlike
                                </button>
                            </a>
                        <?php endif; ?>
                <?php endif; ?>
                        <!--BROJ LAJKOVA -->
                        <?php
                            $lajkovi = App\likes::where('joke_id',$joke->id)->get();
                            $brojLajkova = count($lajkovi);
                        ?>
                        
                        
                        <button id="brojLajkova" disabled class="btn btn-primary">
                            <?php echo e($brojLajkova); ?>

                        </button>
            </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
            <p> Nema viceva </p>
    <?php endif; ?>


    


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>