<?php $__env->startSection('adminSection'); ?>
    <a href="/manageUsers">
        <button class="btn btn-primary" id="dugme">
            Upravljanje korisnicima
        </button>
    </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel.homeAdminPanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>