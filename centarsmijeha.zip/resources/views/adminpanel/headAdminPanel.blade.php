@extends('adminpanel.homeAdminPanel')

@section('adminSection')
    <a href="/manageUsers">
        <button class="btn btn-primary" id="dugme">
            Upravljanje korisnicima
        </button>
    </a>
@endsection